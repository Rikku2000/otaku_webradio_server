const audio = document.getElementById("audio");
const btn = document.getElementById("playpause");
const songlist = document.getElementById("songlist");
const progress = document.getElementById("progress");
const volumeSlider = document.getElementById("volume");

let history = [];
let lastSong = "";
let lastTime = "";
let songDuration = 0;
let songElapsed = 0;

let audio_stream = "http://"+ window.location.hostname +":8010/stream";
let audio_status = "http://"+ window.location.hostname +":8011/status";

audio.src = audio_stream;

volumeSlider.addEventListener("input", () => {
	audio.volume = volumeSlider.value;
});

volumeSlider.value = audio.volume;

btn.addEventListener("click", () => {
	if (audio.paused) {
		audio.play();
		document.getElementById('wallpaper').style.display = 'block';
		btn.textContent = "STOP";
	} else {
		audio.pause();
		audio.src = audio_stream;
		document.getElementById('wallpaper').style.display = 'none';
		btn.textContent = "PLAY";
	}
});

function formatTime(seconds) {
	let m = Math.floor(seconds / 60);
	let s = Math.floor(seconds % 60);

	return m + ":" + (s < 10 ? "0" : "") + s;
}

async function updateStatus() {
	try {
        const res = await fetch(audio_status);
        const data = await res.json();

		if (data.error) {
			document.getElementById("nowplaying").innerHTML = data.error;
			document.getElementById("meta").textContent = "";

			return;
		}

		var song = data.song.slice(0, 31) + (data.song.length > 31 ? "..." : "");
		document.getElementById("nowplaying").innerHTML = "<div class='equalizer'><span></span><span></span><span></span></div> "+ song +"</br><small>"+ formatTime(data.elapsed) +" / "+ formatTime(data.duration) +"</small>";
		var next = data.next.slice(0, 31) + (data.next.length > 31 ? "..." : "");
		document.getElementById("meta").innerHTML = "</br><b>NEXT</b><h2><small>" + next + "</small></h2>";
		document.getElementById("listeners").innerHTML = data.listeners +" / "+ data.slots +" Listeners";
		songDuration = data.duration;
		songElapsed = data.elapsed;

		if (data.song !== lastSong) {
			if (lastSong !== "") {
				history.unshift(lastSong);
				if (history.length>5)
					history.pop();
			}

			lastSong = data.song;
			songlist.innerHTML = history.map(s => s + "</br>").join("");
		}
	} catch (e) {
		console.error("Failed to load status:", e);
		document.getElementById("nowplaying").innerHTML = "Waiting for server...";
		document.getElementById("meta").textContent = "";
	}
}

function updateProgress() {
	if (songDuration > 0) {
		let width = Math.min((songElapsed / songDuration) * 100, 100);
		progress.style.width = width + "%";

		if (!audio.paused)
			songElapsed++;
	}
}

function createPetal() {
	const petal = document.createElement("div");
	petal.classList.add("petal");
	petal.style.left = Math.random() * 100 + "vw";
	petal.style.width = petal.style.height = (10 + Math.random() * 15) + "px";

	if (Math.random() > 0.5) {
		petal.style.background = "radial-gradient(circle at 30% 30%, #ffb3ec, #ff66cc 70%)";
		petal.style.boxShadow = "0 0 6px #ff66ccaa, 0 0 12px #ff99e655, 0 0 20px #ffb3ec44";
	} else {
		petal.style.background = "radial-gradient(circle at 30% 30%, #99f6ff, #1efcff 70%)";
		petal.style.boxShadow = "0 0 6px #1efcffaa, 0 0 12px #99f6ff55, 0 0 20px #1efcff44";
	}

	petal.style.animationDuration = 5 + Math.random() * 7 + "s";
	document.body.appendChild(petal);

	setTimeout(() => {
		petal.remove();
	}, 12000);
}

setInterval(createPetal, 500);

function openPopup(id) {
	document.getElementById(id).classList.add("show");
}

function closePopup(id) {
	document.getElementById(id).classList.remove("show");
}

document.getElementById("openImprint").addEventListener("click", e => {
	e.preventDefault();
	openPopup("imprintPopup");
});

document.getElementById("openBroadcast").addEventListener("click", e => {
	e.preventDefault();
	openPopup("BroadcastPopup");
});

document.getElementById("openData").addEventListener("click", e => {
	e.preventDefault();
	openPopup("dataPopup");
});

document.querySelectorAll(".close").forEach(btn => {
	btn.addEventListener("click", () => closePopup(btn.dataset.close));
});

window.addEventListener("click", e => {
	if (e.target.classList.contains("popup")) {
		e.target.classList.remove("show");
	}
});

function tryResume() {
	audio.load();
	audio.currentTime = lastTime;
	audio.play().catch(() => { setTimeout(tryResume, 1000); });
}

audio.addEventListener("error", () => { tryResume(); });
audio.addEventListener("ended", () => { tryResume(); });

setInterval(() => { if (!isNaN(audio.currentTime) && audio.currentTime > 0) lastTime = audio.currentTime; }, 1000);

setInterval(updateStatus, 1000);
setInterval(updateProgress, 1000);

updateStatus();
